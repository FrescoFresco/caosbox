
import 'package:flutter/foundation.dart';
import '../models/enums.dart';
import '../models/item.dart';
import '../config/blocks.dart';

class AppState extends ChangeNotifier {
  final _items = {ItemType.idea: <Item>[], ItemType.action: <Item>[]};
  final Map<String, Set<String>> _links = {};
  final Map<ItemType, int> _counters = {ItemType.idea: 0, ItemType.action: 0};
  final Map<String, Item> _cache = {};
  final Map<String, String> _notes = {};

  List<Item> items(ItemType t) => List.unmodifiable(_items[t]!);
  List<Item> get all => _items.values.expand((e) => e).toList();
  Set<String> links(String id) => _links[id] ?? {};
  Item? getItem(String id) => _cache[id];
  String note(String id) => _notes[id] ?? '';

  void add(ItemType t, String rawText) {
    final text = rawText.trim();
    if (text.isEmpty) return;
    _counters[t] = (_counters[t] ?? 0) + 1;
    final cfg = t == ItemType.idea ? ideasCfg : actionsCfg;
    final id = '\${cfg.prefix}\${_counters[t]!.toString().padLeft(3, '0')}';
    _items[t]!.insert(0, Item(id, text, t));
    _reindex();
    notifyListeners();
  }

  bool setStatus(String id, ItemStatus status) =>
      _update(id, (it) => it.copyWith(status: status));

  bool updateText(String id, String text) => _update(
        id,
        (it) => Item(
          it.id,
          text,
          it.type,
          it.status,
          it.createdAt,
          DateTime.now(),
          it.statusChanges,
        ),
      );

  void setNote(String id, String v) {
    _notes[id] = v;
    notifyListeners();
  }

  void toggleLink(String a, String b) {
    if (a == b || _cache[a] == null || _cache[b] == null) return;
    final sa = _links.putIfAbsent(a, () => <String>{});
    final sb = _links.putIfAbsent(b, () => <String>{});
    if (sa.remove(b)) {
      sb.remove(a);
    } else {
      sa.add(b);
      sb.add(a);
    }
    notifyListeners();
  }

  bool _update(String id, Item Function(Item) cb) {
    final item = _cache[id];
    if (item == null) return false;
    final list = _items[item.type]!;
    final idx = list.indexWhere((e) => e.id == id);
    if (idx < 0) return false;
    list[idx] = cb(item);
    _reindex();
    notifyListeners();
    return true;
  }

  void _reindex() {
    _cache
      ..clear()
      ..addAll({for (final it in all) it.id: it});
  }
}
