
import 'dart:async';
import 'package:flutter/material.dart';
import '../../state/app_state.dart';
import '../../models/item.dart';
import '../../utils/extensions.dart';
import '../style.dart';
import '../widgets/item_card.dart';
import '../../models/enums.dart';

void showInfoModal(BuildContext ctx, Item it, AppState st) {
  showModalBottomSheet(
    context: ctx,
    isScrollControlled: true,
    builder: (_) => InfoModal(id: it.id, state: st),
  );
}

class InfoModal extends StatefulWidget {
  final String id;
  final AppState state;
  const InfoModal({super.key, required this.id, required this.state});

  @override State<InfoModal> createState() => _InfoModalState();
}

class _InfoModalState extends State<InfoModal> {
  late final TextEditingController _editor;
  late final TextEditingController _note;
  Timer? _deb1, _deb2;

  @override
  void initState() {
    super.initState();
    _editor =
        TextEditingController(text: widget.state.getItem(widget.id)!.text);
    _note = TextEditingController(text: widget.state.note(widget.id));
  }

  @override
  void dispose() {
    _deb1?.cancel();
    _deb2?.cancel();
    _editor.dispose();
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.state,
      builder: (_, __) {
        final item = widget.state.getItem(widget.id)!;
        final linked = widget.state
            .all
            .where((i) => widget.state.links(widget.id).contains(i.id))
            .toList();

        return FractionallySizedBox(
          heightFactor: 0.9,
          child: DefaultTabController(
            length: 4,
            child: Material(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(children: [
                      const Icon(Icons.info),
                      const SizedBox(width: 8),
                      Expanded(
                          child: Text(item.id, style: Style.title)),
                      IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.close)),
                    ]),
                  ),
                  const TabBar(
                    tabs: [
                      Tab(icon: Icon(Icons.description), text: 'Contenido'),
                      Tab(icon: Icon(Icons.link),         text: 'Relacionado'),
                      Tab(icon: Icon(Icons.info),         text: 'Info'),
                      Tab(icon: Icon(Icons.timer),        text: 'Tiempo'),
                    ],
                  ),
                  Expanded(
                    child: TabBarView(
                      children: [
                        _contentTab(item),
                        _linksTab(linked),
                        _infoTab(item, linked.length),
                        _noteTab(),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _contentTab(Item item) => Padding(
        padding: const EdgeInsets.all(16),
        child: TextField(
          controller: _editor,
          decoration: const InputDecoration(border: OutlineInputBorder()),
          maxLines: null,
          onChanged: (txt) {
            _deb1?.cancel();
            _deb1 =
                Timer(const Duration(milliseconds: 300), () => widget.state.updateText(item.id, txt));
          },
        ),
      );

  Widget _linksTab(List<Item> linked) => linked.isEmpty
      ? const Center(child: Text('Sin relaciones'))
      : ListView.builder(
          itemCount: linked.length,
          itemBuilder: (_, i) => ItemCard(
            item: linked[i],
            state: widget.state,
            expanded: false,
            onToggle: () {},
            onInfo: () => showInfoModal(context, linked[i], widget.state),
          ),
        );

  Widget _infoTab(Item it, int links) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _row('Creado:', it.createdAt.f),
          _row('Modificado:', it.modifiedAt.f),
          _row('Estado:', it.status.name),
          _row('Cambios estado:', '${it.statusChanges}'),
          _row('Enlaces:', '$links'),
        ],
      );

  Widget _noteTab() => Padding(
        padding: const EdgeInsets.all(16),
        child: TextField(
          controller: _note,
          decoration: const InputDecoration(border: OutlineInputBorder()),
          maxLines: null,
          onChanged: (txt) {
            _deb2?.cancel();
            _deb2 = Timer(const Duration(milliseconds: 300),
                () => widget.state.setNote(widget.id, txt));
          },
        ),
      );

  Widget _row(String l, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          SizedBox(width: 120, child: Text(l, style: Style.info)),
          Expanded(child: Text(v)),
        ]),
      );
}
