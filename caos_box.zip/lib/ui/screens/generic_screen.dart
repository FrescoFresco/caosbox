
import 'package:flutter/material.dart';

import '../../config/blocks.dart';
import '../../models/enums.dart';
import '../../state/app_state.dart';
import '../../ui/widgets/composer_card.dart';
import '../../ui/widgets/chips_panel.dart';
import '../../ui/widgets/item_card.dart';
import '../../utils/extensions.dart';
import 'info_modal.dart';

class GenericScreen extends StatefulWidget {
  final Block block;
  final AppState state;
  const GenericScreen({super.key, required this.block, required this.state});

  @override State<GenericScreen> createState() => _GenericScreenState();
}

class _GenericScreenState extends State<GenericScreen>
    with AutomaticKeepAliveClientMixin {
  late final TextEditingController _composer;
  final _filter = FilterSet();
  final _expanded = <String>{};

  @override void initState() {
    super.initState();
    _composer = TextEditingController();
  }

  @override void dispose() {
    _composer.dispose();
    _filter.dispose();
    super.dispose();
  }

  void _refresh() => setState(() {});

  @override bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final type = widget.block.type!;
    final cfg  = widget.block.cfg!;
    final items = widget.state.items(type);

    final filtered = items.where((it) {
      final q = _filter.text.text.toLowerCase();
      if (q.isNotEmpty && !('${it.id} ${it.text}'.toLowerCase().contains(q))) {
        return false;
      }
      bool pass(FilterKey k, bool v) => switch (_filter.modes[k]!) {
            FilterMode.off     => true,
            FilterMode.include => v,
            FilterMode.exclude => !v,
          };
      return pass(FilterKey.completed, it.status == ItemStatus.completed) &&
          pass(FilterKey.archived, it.status == ItemStatus.archived) &&
          pass(FilterKey.hasLinks, widget.state.links(it.id).isNotEmpty);
    }).toList();

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          ComposerCard(
            icon: cfg.icon,
            hint: cfg.hint,
            controller: _composer,
            onAdd: () {
              widget.state.add(type, _composer.text);
              _composer.clear();
              _refresh();
            },
            onCancel: () {
              _composer.clear();
              _refresh();
            },
          ),
          const SizedBox(height: 12),
          ChipsPanel(set: _filter, onUpdate: _refresh),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.builder(
              itemCount: filtered.length,
              itemBuilder: (_, i) {
                final it   = filtered[i];
                final open = _expanded.contains(it.id);
                return ItemCard(
                  item: it,
                  state: widget.state,
                  expanded: open,
                  onToggle: () {
                    open ? _expanded.remove(it.id) : _expanded.add(it.id);
                    _refresh();
                  },
                  onInfo: () => showInfoModal(context, it, widget.state),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
