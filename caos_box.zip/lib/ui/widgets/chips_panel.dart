
import 'package:flutter/material.dart';
import '../../models/enums.dart';

class FilterSet {
  final text = TextEditingController();
  final modes = {
    FilterKey.completed: FilterMode.off,
    FilterKey.archived:  FilterMode.off,
    FilterKey.hasLinks:  FilterMode.off,
  };

  void dispose() => text.dispose();
  void cycle(FilterKey k) => modes[k] = FilterMode.values[(modes[k]!.index + 1) % 3];
  void clear() {
    text.clear();
    for (final k in modes.keys) modes[k] = FilterMode.off;
  }

  bool get hasActive => text.text.isNotEmpty || modes.values.any((m) => m != FilterMode.off);
}

typedef VoidCb = void Function();

class ChipsPanel extends StatelessWidget {
  final FilterSet set;
  final VoidCb onUpdate;

  const ChipsPanel({super.key, required this.set, required this.onUpdate});

  @override
  Widget build(BuildContext context) {
    Widget chip(FilterKey k, String label) {
      final m = set.modes[k]!;
      final on = m != FilterMode.off;
      final color = on ? (m == FilterMode.include ? Colors.green : Colors.red).withAlpha(50) : null;
      final txt  = m == FilterMode.exclude ? '⊘$label' : label;
      return FilterChip(
        label: Text(txt),
        selected: on,
        selectedColor: color,
        onSelected: (_) { set.cycle(k); onUpdate(); },
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TextField(
          controller: set.text,
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Buscar...'),
          onChanged: (_) => onUpdate(),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: [
            chip(FilterKey.completed, '✓'),
            chip(FilterKey.archived,  '↓'),
            chip(FilterKey.hasLinks,  '~'),
            if (set.hasActive)
              IconButton(icon: const Icon(Icons.clear, size: 16), onPressed: () { set.clear(); onUpdate(); }),
          ],
        ),
      ],
    );
  }
}
