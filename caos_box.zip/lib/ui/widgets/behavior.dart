
import 'package:flutter/material.dart';
import '../../models/enums.dart';

class Behavior {
  static Future<bool> swipe(
    DismissDirection dir,
    ItemStatus status,
    void Function(ItemStatus) on,
  ) async {
    on(dir == DismissDirection.startToEnd
        ? (status == ItemStatus.completed ? ItemStatus.normal : ItemStatus.completed)
        : (status == ItemStatus.archived  ? ItemStatus.normal : ItemStatus.archived));
    return false;
  }

  static Widget bg(bool secondary) => Container(
        color: (secondary ? Colors.grey : Colors.green).withAlpha(50),
        child: Align(
          alignment: secondary ? Alignment.centerRight : Alignment.centerLeft,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Icon(
              secondary ? Icons.archive : Icons.check,
              color: secondary ? Colors.grey : Colors.green,
            ),
          ),
        ),
      );
}
