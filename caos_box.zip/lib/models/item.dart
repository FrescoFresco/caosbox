
import 'enums.dart';

class Item {
  final String id, text;
  final ItemType type;
  final ItemStatus status;
  final DateTime createdAt, modifiedAt;
  final int statusChanges;

  Item(
    this.id,
    this.text,
    this.type, [
    this.status = ItemStatus.normal,
    DateTime? created,
    DateTime? modified,
    this.statusChanges = 0,
  ])  : createdAt = created ?? DateTime.now(),
        modifiedAt = modified ?? DateTime.now();

  Item copyWith({ItemStatus? status}) {
    final newStatus = status ?? this.status;
    final changed = newStatus != this.status;
    return Item(
      id,
      text,
      type,
      newStatus,
      createdAt,
      changed ? DateTime.now() : modifiedAt,
      changed ? statusChanges + 1 : statusChanges,
    );
  }
}
